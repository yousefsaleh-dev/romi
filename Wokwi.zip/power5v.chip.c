#include "wokwi-api.h"
#include <stdlib.h>

typedef struct {
  pin_t v5;
  pin_t gnd;
} chip_state_t;

void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));

  chip->v5 = pin_init("+5V", ANALOG);
  chip->gnd = pin_init("GND", OUTPUT_LOW);

  pin_dac_write(chip->v5, 5.0);
}