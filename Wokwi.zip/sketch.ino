#include <ESP32Servo.h>

// ========================
// ROMI Pin Map
// ========================
#define SERVO_PIN      23
#define RED_LED_PIN    25
#define GREEN_LED_PIN  26
#define CALL_BUTTON    33

Servo doorServo;

// Servo positions
const int DOOR_CLOSED = 0;
const int DOOR_OPEN   = 90;

// Call state
bool callActive = false;

// Button debounce
bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 40;


// ========================
// LED state
// ========================
void updateCallLEDs() {
  if (callActive) {
    digitalWrite(RED_LED_PIN, HIGH);
    digitalWrite(GREEN_LED_PIN, LOW);
  } else {
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(GREEN_LED_PIN, HIGH);
  }
}


// ========================
// Servo control
// ========================
void openDoor() {
  Serial.println("[DOOR] Opening...");
  doorServo.write(DOOR_OPEN);
}

void closeDoor() {
  Serial.println("[DOOR] Closing...");
  doorServo.write(DOOR_CLOSED);
}


// ========================
// Startup hardware test
// ========================
void startupTest() {
  Serial.println();
  Serial.println("================================");
  Serial.println(" ROMI HARDWARE SELF TEST");
  Serial.println("================================");

  // LEDs
  Serial.println("[TEST] Red LED");
  digitalWrite(RED_LED_PIN, HIGH);
  delay(500);
  digitalWrite(RED_LED_PIN, LOW);

  Serial.println("[TEST] Green LED");
  digitalWrite(GREEN_LED_PIN, HIGH);
  delay(500);
  digitalWrite(GREEN_LED_PIN, LOW);

  // Servo
  Serial.println("[TEST] Servo -> 0 degrees");
  doorServo.write(0);
  delay(700);

  Serial.println("[TEST] Servo -> 90 degrees");
  doorServo.write(90);
  delay(700);

  Serial.println("[TEST] Servo -> 0 degrees");
  doorServo.write(0);
  delay(700);

  Serial.println("[TEST] Finished!");
  Serial.println();

  Serial.println("Controls:");
  Serial.println("  O = Open door");
  Serial.println("  C = Close door");
  Serial.println("  T = Servo test");
  Serial.println();

  updateCallLEDs();
}


// ========================
// Button handling
// ========================
void checkCallButton() {
  bool reading = digitalRead(CALL_BUTTON);

  if (reading != lastButtonReading) {
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {

    if (reading != stableButtonState) {
      stableButtonState = reading;

      // INPUT_PULLUP:
      // LOW = pressed
      if (stableButtonState == LOW) {

        callActive = !callActive;

        if (callActive) {
          Serial.println("[CALL] Call started");
        } else {
          Serial.println("[CALL] Call ended");
        }

        updateCallLEDs();
      }
    }
  }

  lastButtonReading = reading;
}


// ========================
// Serial servo controls
// ========================
void checkSerial() {

  if (!Serial.available()) {
    return;
  }

  char command = Serial.read();

  if (command == 'o' || command == 'O') {
    openDoor();
  }

  else if (command == 'c' || command == 'C') {
    closeDoor();
  }

  else if (command == 't' || command == 'T') {

    Serial.println("[SERVO TEST] Starting...");

    doorServo.write(0);
    delay(700);

    doorServo.write(90);
    delay(700);

    doorServo.write(180);
    delay(700);

    doorServo.write(90);
    delay(700);

    doorServo.write(0);

    Serial.println("[SERVO TEST] Done");
  }
}


// ========================
// SETUP
// ========================
void setup() {

  Serial.begin(115200);

  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);

  pinMode(CALL_BUTTON, INPUT_PULLUP);

  doorServo.setPeriodHertz(50);
  doorServo.attach(SERVO_PIN, 500, 2400);

  delay(500);

  startupTest();
}


// ========================
// LOOP
// ========================
void loop() {

  checkCallButton();

  checkSerial();

  delay(5);
}